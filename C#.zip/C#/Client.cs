using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace AdventOfCode {
    
    public static class Solution {
        public static void Main() {
            //var input = System.IO.File.ReadAllText("../input.txt");
        }
    }
}