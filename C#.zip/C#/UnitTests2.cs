using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace AdventOfCode
{
    [TestClass]
    public class UnitTests2
    {
        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
           
            // Act

            // Assert
        }

        [TestMethod]
        public void TestMethod2()
        {
            // Arrange

            // Act

            // Assert
        }
    }
}
